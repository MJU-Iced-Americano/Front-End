import './footer.css';
import SocoaF from '../socoa-ver2.png';

const Footer =() => {
    return (
        <footer className="footer">
            <div className="footerAreaLeft">
                <div className="logoBG"><img src={SocoaF} alt='logo image' className="socoaLogoF"/></div>
                <div className="textField">
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                    왜 안될까요? 모르겠습니다 다시 한번 해보세요
                </div>

            </div>
        </footer>
    )
}

export default Footer;